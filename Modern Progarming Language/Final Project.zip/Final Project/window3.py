from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QTextEdit, QLineEdit
import pandas
import sys

class Window3(QMainWinow):
    def __init__(self):
        super.__init__()

        self.setWindowTitle("Magic Mirror - Weather")
        self.getGeometry(100, 100, 800, 400)

        weather = pandas.read_xml("https://opendata.cwa.gov.tw/fileapi/v1/opendataapi/F-C0032-003?Authorization=CWA-FCAC57E3-71AA-477D-A7A8-CC84F4979C47&downloadType=WEB&format=XML")
        

