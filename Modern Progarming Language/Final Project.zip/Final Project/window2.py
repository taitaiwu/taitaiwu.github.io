import sys
import threading
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QTextEdit, QLineEdit
import openai
import pyttsx3
from flask import Flask, request, jsonify
import requests

# Flask 部分
app = Flask(__name__)

openai.api_key = 'YOUR_API_KEYsk-proj-pq1_9ZDTaZpKYuMkOWlC41h_DhLoMr_PI_yI97r0hChgdnczOT2XiWF6qQzkkKVhuknqrPhG6DT3BlbkFJpEKLNrwycIAAsPcLg7OLXIxkks8lIlr87aIWCtgPczJdbl4JGTqhWFguONe_FtBnEf3b4oCngA'  # 使用環境變數存放 API 金鑰

def speak_text(text):
    """ 每次调用时重新初始化 pyttsx3 引擎，并朗读文本 """
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

@app.route('/magic_mirror', methods=['POST'])
def magic_mirror():
    user_input = request.json.get('question')
    if not user_input:
        return jsonify({'error': '问题未提供'}), 400

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "你是一个有用的助手。"},
                {"role": "user", "content": user_input}
            ],
            max_tokens=150
        )
        answer = response['choices'][0]['message']['content'].strip()
        threading.Thread(target=speak_text, args=(answer,)).start()
        return jsonify({'answer': answer})
    except Exception as e:
        return jsonify({'error': '发生错误', 'details': str(e)}), 500

# PyQt 視窗部分
class Window2(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Magic_Mirror_Chatbot")
        self.setGeometry(100, 100, 800, 400)

        self.chat_display = QTextEdit(self)
        self.chat_display.setReadOnly(True)
        self.chat_display.setGeometry(50, 120, 700, 180)

        self.user_input = QLineEdit(self)
        self.user_input.setPlaceholderText("請輸入您的問題...")
        self.user_input.setGeometry(50, 310, 600, 40)

        self.send_button = QPushButton('送出', self)
        self.send_button.setGeometry(670, 310, 80, 40)
        self.send_button.clicked.connect(self.handle_user_input)

    def handle_user_input(self):
        question = self.user_input.text().strip()
        if question:
            self.chat_display.append(f"<b>您:</b> {question}")
            self.user_input.clear()
            answer = chat_with_api(question)
            self.chat_display.append(f"<b>機器人:</b> {answer}")

def chat_with_api(question):
    url = "http://localhost:5000/magic_mirror"
    headers = {"Content-Type": "application/json"}
    payload = {"question": question}

    try:
        response = requests.post(url, json=payload, headers=headers)
        if response.status_code == 200:
            return response.json().get('answer', "沒有返回答案")
        return f"錯誤: 狀態碼 {response.status_code}"
    except Exception as e:
        return f"請求失敗: {e}"

if __name__ == '__main__':
    threading.Thread(target=lambda: app.run(host='0.0.0.0', port=5000)).start()
    app = QApplication(sys.argv)
    window = Window2()
    window.show()
    sys.exit(app.exec_())
