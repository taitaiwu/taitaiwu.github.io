import sys
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QApplication, QMainWindow, QPushButton, QLabel

from window2 import Window2

class Window1(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("聊天機器人")
        self.resize(800, 400)
        self.setStyleSheet('''background: rgba(223, 245, 229, 0.97);''')

        label1 = QLabel(self)
        label1.setText("歡迎使用 金門大學資工系 居家魔鏡")
        label1.setGeometry(100, 150, 800, 40)
        label1.setStyleSheet('''font-size: 40px; font-family: "微軟正黑體"; text-align: center;''')

        button1 = QPushButton('聊天機器人', self)
        button1.setGeometry(290, 210, 110, 40)
        button1.setStyleSheet('''background: #fffafa; letter-spacing: 5px;''')

        button2 = QPushButton('空氣品質', self)
        button2.setGeometry(410, 210, 110, 40)
        button2.setStyleSheet('''background: #fffafa; letter-spacing: 5px;''')

        button1.clicked.connect(self.open_chatbot)
        button2.clicked.connect(self.open_air_quality)

    def open_chatbot(self):
        self.window2 = Window2()
        self.window2.show()

    def open_air_quality(self):
        print("空氣品質視窗開啟")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window1 = Window1()
    window1.show()
    sys.exit(app.exec_())
